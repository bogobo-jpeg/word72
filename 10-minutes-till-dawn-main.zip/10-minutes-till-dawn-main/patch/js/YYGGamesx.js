function YYGGames () {
  this.showSplash = function (data= null) {
    console.log("--fx--YYGGames--showSplash--");
  }
  this.startupByYad= function (obj) {
    console.log("--fx--YYGGames--startupByYad--", obj);
  }
}
YYGGames= new YYGGames();
